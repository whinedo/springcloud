mvn spring-boot:run -Drun.jvmArguments="-Dspring.profiles.active=subject" &
mvn spring-boot:run -Drun.jvmArguments="-Dspring.profiles.active=verb" &
mvn spring-boot:run -Drun.jvmArguments="-Dspring.profiles.active=article" &
mvn spring-boot:run -Drun.jvmArguments="-Dspring.profiles.active=adjective" &
mvn spring-boot:run -Drun.jvmArguments="-Dspring.profiles.active=noun" 
